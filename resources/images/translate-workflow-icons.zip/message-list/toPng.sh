# Exports all SVGs in the current folder to PNG
# It uses inkscape to do the conversion, so you need it.

#!/bin/bash
FILES=*.svg
mkdir png
for f in $FILES
do
  echo "Converting $f ..."

  inkscape $f -e png/${f%.*}.png
done
